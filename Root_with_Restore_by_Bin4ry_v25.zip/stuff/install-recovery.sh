#!/system/bin/sh
/system/bin/stop ric
