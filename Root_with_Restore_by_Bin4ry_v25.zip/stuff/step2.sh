# remount rw
/system/bin/stop ric
/system/bin/mount -o remount,rw -t ext4 /dev/block/platform/msm_sdcc.1/by-name/system /system

# busybox
echo intall /system/xbin/busybox ...
/system/bin/dd if=/data/local/tmp/busybox of=/system/xbin/busybox
/system/bin/chown root.shell /system/xbin/busybox
/system/bin/chmod 04755 /system/xbin/busybox
/system/xbin/busybox --install -s /system/xbin

# su
echo install /system/bin/su ...
/system/bin/dd if=/data/local/tmp/su of=/system/bin/su
/system/bin/mkdir /system/bin/.ext
/system/bin/dd if=/data/local/tmp/.su of=/system/bin/.ext/.su
/system/bin/chown root.root /system/bin/su
/system/bin/chmod 06755 /system/bin/su
/system/bin/rm /system/xbin/su 2>/dev/null
/system/bin/ln -s /system/bin/su /system/xbin/su

# anti ric
echo intall /system/etc/install-recovery.sh ...
/system/bin/rm /system/bin/ric
/system/bin/dd if=/data/local/tmp/ric of=/system/bin/ric
/system/bin/chmod 755 /system/bin/ric
/system/bin/rm /data/data/com.sonyericsson.android.servicemenu/lib/libservicemenu.so
/system/bin/dd if=/data/local/tmp/libservicemenu.so of=/data/data/com.sonyericsson.android.servicemenu/lib/libservicemenu.so
/system/bin/chmod 644 /data/data/com.sonyericsson.android.servicemenu/lib/libservicemenu.so
/system/bin/dd if=/data/local/tmp/install-recovery.sh of=/system/etc/install-recovery.sh
/system/bin/chown root.root /system/etc/install-recovery.sh
/system/bin/chmod 0755 /system/etc/install-recovery.sh

# remount ro
/system/bin/mount -o remount,ro -t ext4 /dev/block/platform/msm_sdcc.1/by-name/system /system
