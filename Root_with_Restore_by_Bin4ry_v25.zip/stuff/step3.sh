if [ -e /data/usf- ]; then
	/system/bin/rm -r /data/usf
	/system/bin/mv /data/usf- /data/usf
fi

/system/xbin/rm -r /data/usf
/system/bin/rm -r /data/usf/*
/system/bin/rmdir /data/usf/